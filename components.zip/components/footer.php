<footer>
        <div id="footer_Subscribe_bar">
            <div id="footer_Subscribe_bar_text">
                <h2>Subscribe our newsletter to get <br>
                    the latest news & updates.</h2>
            </div>

            <div id="footer_Subscribe_bar_email">

                <!-- for sending email -->
                <form action="https://formsubmit.co/etilesexports@gmail.com" method="POST">

                    <input type="email" name="email" placeholder="Email Address" required>
                    <input type="hidden" name="_subject" value="some one want to connect with us!">
                    <input type="hidden" name="_captcha" value="false">
                    <input type="hidden" name="_next" value="https://yashdashadiya.github.io/E-tiles/">

                    <button type="submit"><i class="fa-solid fa-arrow-right" style='font-size:24px'></i></button>

                </form>

                <!-- <input type="text" placeholder="Email Address"> -->
                <!-- <button type="submit">
                    <i class="fa-solid fa-arrow-right" style='font-size:24px'></i>
                </button> -->
            </div>

        </div>
        <div id="footer_contect_us_container">
            <div id="footer_contect_us">

                <div id="footer_contect_us_info">
                    <img src="photos/E TILES LOGO  DONE.png" id="footer_contect_us_info_logo" alt="not">
                    <!-- <p>48 10h Street, Office 478 Road 5<br>Morbi, IND 363642</p> -->
                    <p>Trajpar Chokdi, Bhagvati Chamber-3
                         First Floor ,Shop No - 28, Amrut Nagar, Morbi, Gujarat 363641</p>
                    <p>etilesexports@gmail.com</p>
                </div>

                <div id="footer_contect_us_Services">
                    <h2>Services</h2>
                    <p>Vitrified Tiles</p>
                    <p>Wall tiles</p>
                    <p>Floor Tiles</p>
                    <p>Sanitary Ware</p>
                    <p>Roof Tiles</p>
                    <!-- <p>Carpet Setup</p> -->
                </div>
                <div id="footer_contect_us_QuickLinks">
                    <h2>Quick Links</h2>
                    <p>Contact us</p>
                    <p>Member</p>
                    <p>Our project</p>
                    <p>Woodhard</p>
                    <p>About company</p>
                    <p>News update</p>
                </div>
                <div id="footer_contect_us_GetInTouch">
                    <h2>Get In Touch</h2>
                    <div id="footer_contect_us_GetInTouch_icon_container">
                        <div class="footer_contect_us_GetInTouch_icon">
                            <i class="fa-brands fa-instagram"></i>
                        </div>
                        <div class="footer_contect_us_GetInTouch_icon">
                            <a href="https://wa.me/919426448461" target="_blank" >
                                <i class="fa-brands fa-whatsapp"></i>
                            </a>
                        </div>
                        <div class="footer_contect_us_GetInTouch_icon">
                            <i class="fa-brands fa-facebook"></i>
                        </div>
                        <div class="footer_contect_us_GetInTouch_icon">
                            <i class="fa-brands fa-twitter"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>