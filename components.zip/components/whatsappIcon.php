<span id="whatappIcon">
        <a href="https://wa.me/919725061018" target="_blank">
            <i class="fa-brands fa-whatsapp" style="font-size:xx-large;color: white;" onclick=""></i>
        </a>
    </span>