<div id="nav">
            <img src="photos/E TILES LOGO  DONE.png" class="logo" alt="not">
            <div id="nav_button_container">
                <div class="nav_button_name">
                    home
                </div>
                <div class="nav_button_name">
                    product
                </div>
                <div class="nav_button_name">
                    contect
                </div>
                <div class="nav_button_name">
                    download
                </div>
                <div class="nav_button_name">
                    experd guidance
                </div>
            </div>
            <div id="nav_icon_container">
                <!-- <i class="material-icons w3-xxlarge icon" onclick="openInfo()">menu</i> -->
                <i class="fa-solid fa-bars icon" onclick="openInfo()"></i>

                <!-- mobile content contect info -->
                <div id="mobile_nav_content_container">
                    <div id="mobile_nav_content">

                        <img src="photos/E TILES LOGO  DONE.png" id="mobile_nav_content_logo" alt="not">
                        <!-- <i class="material-icons w3-xxxsmall icon" id="mobile_nav_content_close_icon" onclick="openInfo()">close</i> -->
                        <i class="fa-solid fa-xmark icon" id="mobile_nav_content_close_icon" onclick="openInfo()"></i>
                        <h3 class="mobile_nav_content_heading">About Us</h3>
                        
                        <p class="mobile_nav_content_text">Lorem Ipsum is simply dummy text of the printing and
                            typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the
                            1500s,</p>

                        <h3 class="mobile_nav_content_heading">Contact Info</h3>

                        <p class="mobile_nav_content_text" style="color: #f37e21;">Address</p>
                        <!-- <p class="mobile_nav_content_text">48 10h Street, Office 478 Road 5 Morbi, IND 363642</p> -->
                        <p class="mobile_nav_content_text">Trajpar Chokdi, Bhagvati Chamber-3,First Floor ,Shop No - 28, Amrut Nagar, Morbi, Gujarat 363641</p>
                        
                        <p class="mobile_nav_content_text" style="color: #f37e21;">Phone</p>
                        <p class="mobile_nav_content_text">+91 9426448461</p>

                        <p class="mobile_nav_content_text" style="color: #f37e21;">Email</p>
                        <p class="mobile_nav_content_text">etilesexports@gmail.com</p>

                    </div>
                </div>
                <!-- <i id="nav_icon" style="font-size:30px" class="fa">&#xf0c9;</i> -->
            </div>
        </div>