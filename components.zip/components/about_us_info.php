<div id="about_us_info">
    <div id="about_us_info_heading">
        <div id="about_us_info_heading_title">ABOUT US</div>
        <h2 id="about_us_info_heading_welcome">Welcome to <br>E-Tiles Export</h2>
    </div>
    <div>
        <p class="about_us_info_detail_p">Inclusive of the longstanding experience of the founders, the architects and building professionals, the design experts as well as the tile technology engineers we have ensured that each tile range commensurates with the quality impact making it totally fit into the curious segment.</p>
        <br>
        <p class="about_us_info_detail_p">The promoters of E-Tiles Esports have a vet experience of more than 20 years in tiles
            manufacturing unit, which make company in front foot in quality and design development</p>
    </div>
    <?php include 'flip_icon_bar.php' ?>

</div>