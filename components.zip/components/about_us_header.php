<section class="about_us_page_header">
    <div class="page_header__bg" >
        <div class="about_us_page_header_container">
            <div class="about_us_page_header__wrapper">
                <div class="about_us_page_header__content">
                    <h2>About Company</h2>
                    <div class="about_us_page_header__menu">
                        <ul>
                            <li>Home/ </li>
                            <li>About us</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
</section>