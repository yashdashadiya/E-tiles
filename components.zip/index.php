<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Tiles</title>
    <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"> -->
    <script src="https://kit.fontawesome.com/ad57e5ca9d.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <script src="javascript.js"></script>
    <link rel="stylesheet" href="css.css">
</head>

<body>
    <div id="preview__header">
        <?php include 'components/nav.php'; ?>
        <img src="photos/5.jpg" id="image" width="100%" alt="not">
    </div>

    <?php include 'components/whatsappIcon.php'; ?>


    <!----------------------footer----------------------->
    <?php include 'components/footer.php' ?>
    <button onclick="window.location.href='About_us.php'">Click me</button>


    <script>
        var imageSources = ["photos/1.jpg", "photos/2.jpg", "photos/3.png", "photos/4.jpg", "photos/5.jpg"];

        var index = 0;
        setInterval(function() {
            if (index === imageSources.length) {
                index = 0;
            }
            document.getElementById("image").src = imageSources[index];
            index++;
        }, 5000);
        
    </script>



</body>

</html>