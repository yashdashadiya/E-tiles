<!-- <div id="about_us_img1">
    <img src="about-v1-img1.jpg" id="about_us_img" alt="img">
</div>
<span id="about_us_img2">
    <img src="about-v1-img2.jpg" id="about_us_img" alt="img">
</span>
<div>
    
</div> -->

<div id="about_us_img">
    <div class="about_us_img1">
        <img src="photos/about-v1-img1.jpg" alt="">
    </div>

    <div class="dotedimg">
        <?php include 'components/dotedImg.php' ?>
    </div>

    <div class="about_us_img2">
        <img src="photos/about-v1-img2.jpg" style="padding:15px; background: #ffffff;" alt="">
    </div>
</div>